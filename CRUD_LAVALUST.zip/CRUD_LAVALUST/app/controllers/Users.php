<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Users extends Controller {

    public function __construct(){
        parent::__construct();
        $this->call->model('users_model');
    }

    // Serve the main view with DataTable setup
    public function index() {
        $this->call->view('index');
    }

    // Fetch users for DataTables (AJAX)
    public function list() {
        $users = $this->users_model->getUsers();
        // Return the users as JSON for DataTables
        echo json_encode(['data' => $users]);
    }

    // Store a new user (AJAX)
    public function store() {
        $data = [
            'reml_last_name' => $_POST['reml_last_name'],
            'reml_first_name' => $_POST['reml_first_name'],
            'reml_email' => $_POST['reml_email'],
            'reml_gender' => $_POST['reml_gender'],
            'reml_address' => $_POST['reml_address'],
        ];
    
        if ($this->users_model->user_create($data)) {
            echo json_encode(['status' => 'success', 'message' => 'User added successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add user.']);
        }
    }
    

    // Fetch a single user for editing (AJAX)
    public function edit($id) {
        $user = $this->users_model->getUserById($id);
        if ($user) {
            echo json_encode($user);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        }
    }

    // Update an existing user (AJAX)
    public function update($id) {
        $data = [
            'reml_last_name' => $_POST['reml_last_name'],
            'reml_first_name' => $_POST['reml_first_name'],
            'reml_email' => $_POST['reml_email'],
            'reml_gender' => $_POST['reml_gender'],
            'reml_address' => $_POST['reml_address'],
        ];

        if ($this->users_model->update_user($id, $data)) {
            echo json_encode(['status' => 'success', 'message' => 'User updated successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update user.']);
        }
    }

    // Delete a user (AJAX)
    public function delete($id) {
        if ($this->users_model->delete_user($id)) {
            echo json_encode(['status' => 'success', 'message' => 'User deleted successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete user.']);
        }
    }
}
