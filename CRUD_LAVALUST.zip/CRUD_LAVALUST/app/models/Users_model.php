<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Users_model extends Model {

    public function __construct() {
        parent::__construct();
        lava_instance()->database(); // Ensure the database instance is initialized
    }

    // Get all users
    public function getUsers() {
        try {
            return $this->db->table('reml_users')->get_all();
        } catch (Exception $e) {
            $this->logError('Error fetching users', $e);
            return [];
        }
    }

    // Get a single user by ID
    public function getUserById($id) {
        try {
            return $this->db->table('reml_users')->where('id', $id)->get();
        } catch (Exception $e) {
            $this->logError('Error fetching user by ID', $e);
            return null;
        }
    }

    // Create a new user
    public function user_create($data) {
        try {
            return $this->db->table('reml_users')->insert($data);
        } catch (Exception $e) {
            $this->logError('Error creating user', $e);
            return false;
        }
    }

    // Update a user's data
    public function update_user($id, $data) {
        try {
            return $this->db->table('reml_users')->where('id', $id)->update($data);
        } catch (Exception $e) {
            $this->logError('Error updating user', $e);
            return false;
        }
    }

    // Delete a user
    public function delete_user($id) {
        try {
            return $this->db->table('reml_users')->where('id', $id)->delete();
        } catch (Exception $e) {
            $this->logError('Error deleting user', $e);
            return false;
        }
    }

    // Custom error logging function
    private function logError($message, $exception) {
        // Log the error message to a file or to PHP's built-in error log
        error_log($message . ': ' . $exception->getMessage());
        
        // Optional: you can also log to a specific file
        // error_log($message . ': ' . $exception->getMessage(), 3, '/path/to/your/logfile.log');
    }
}
