<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users List</title>
    <!-- Include CSS for DataTables and Bootstrap -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1>User List</h1>
        <button id="addUserBtn" class="btn btn-success mb-3">Add User</button>
        <table id="usersTable" class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
            </thead>
        </table>
    </div>

    <!-- User Modal -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="userForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="userModalLabel">Add User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="userId" name="id">
                        <div class="mb-3">
                            <label for="reml_last_name" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="reml_last_name" name="reml_last_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="reml_first_name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="reml_first_name" name="reml_first_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="reml_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="reml_email" name="reml_email" required>
                        </div>
                        <div class="mb-3">
                            <label for="reml_gender" class="form-label">Gender</label>
                            <select class="form-control" id="reml_gender" name="reml_gender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="reml_address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="reml_address" name="reml_address" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Include JS for jQuery, Bootstrap, and DataTables -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AJAX and DataTables Script -->
    <script>
        $(document).ready(function() {
            const table = $('#usersTable').DataTable({
                ajax: {
                    url: '/users/list', // Adjust according to your endpoint
                    method: 'GET',
                    dataSrc: '' // Assuming your backend sends an array of users
                },
                columns: [
                    { data: 'id' },
                    { data: 'reml_last_name' },
                    { data: 'reml_first_name' },
                    { data: 'reml_email' },
                    { data: 'reml_gender' },
                    { data: 'reml_address' },
                    {
                        data: 'id',
                        render: function(id) {
                            return `
                                <button class="btn btn-primary btn-sm editUserBtn" data-id="${id}">Edit</button>
                                <button class="btn btn-danger btn-sm deleteUserBtn" data-id="${id}">Delete</button>
                            `;
                        }
                    }
                ]
            });

            // Add User Button
            $('#addUserBtn').click(function() {
                $('#userForm')[0].reset();
                $('#userId').val('');
                $('#userModalLabel').text('Add User');
                $('#userModal').modal('show');
            });

            // Handle Form Submission (Add/Edit)
            $('#userForm').submit(function(e) {
                e.preventDefault();
                const id = $('#userId').val();
                const url = id ? `/users/update/${id}` : '/users/store';
                const method = id ? 'PUT' : 'POST';

                $.ajax({
                    url: url,
                    method: method,
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response.message);
                        $('#userModal').modal('hide');
                        table.ajax.reload();
                    },
                    error: function(xhr) {
                        alert('Error: ' + xhr.responseText);
                    }
                });
            });

            // Handle Edit User
            $('#usersTable').on('click', '.editUserBtn', function() {
                const id = $(this).data('id');
                $.get(`/users/edit/${id}`, function(user) {
                    $('#userId').val(user.id);
                    $('#reml_last_name').val(user.reml_last_name);
                    $('#reml_first_name').val(user.reml_first_name);
                    $('#reml_email').val(user.reml_email);
                    $('#reml_gender').val(user.reml_gender);
                    $('#reml_address').val(user.reml_address);
                    $('#userModalLabel').text('Edit User');
                    $('#userModal').modal('show');
                });
            });

            // Handle Delete User
            $('#usersTable').on('click', '.deleteUserBtn', function() {
                const id = $(this).data('id');
                if (confirm('Are you sure you want to delete this user?')) {
                    $.ajax({
                        url: `/users/delete/${id}`,
                        method: 'DELETE',
                        success: function(response) {
                            alert(response.message);
                            table.ajax.reload();
                        },
                        error: function(xhr) {
                            alert('Error: ' + xhr.responseText);
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
