<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Add User</h2>
                <!-- Add an id to the form -->
                <form id="userForm" method="POST">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="firstName" name="reml_first_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="lastName" name="reml_last_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="reml_email" required>
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select class="form-select" id="gender" name="reml_gender" required>
                            <option value="" disabled selected>Select gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="reml_address" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Create User</button>
                    </div>
                </form>

                <!-- Feedback messages will be displayed here -->
                <div id="feedback" class="alert mt-3" style="display:none;"></div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#userForm').submit(function(e) {
                e.preventDefault();  // Prevent the default form submission
                
                // Clear previous feedback
                $('#feedback').hide();

                // Gather form data
                var formData = $(this).serialize();

                // Send AJAX request
                $.ajax({
                    url: '/users/add',  // Ensure this matches the route for adding a user
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        // Show success message
                        $('#feedback').removeClass('alert-danger').addClass('alert-success')
                            .text(response.message || 'User created successfully!')
                            .show();
                        
                        // Optionally reset the form or redirect
                        $('#userForm')[0].reset();
                    },
                    error: function(xhr, status, error) {
                        // Show error message
                        $('#feedback').removeClass('alert-success').addClass('alert-danger')
                            .text('An error occurred: ' + (xhr.responseJSON.message || 'Please try again later.'))
                            .show();
                    }
                });
            });
        });
    </script>
</body>
</html>
